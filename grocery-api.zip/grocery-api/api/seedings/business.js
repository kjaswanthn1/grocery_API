module.exports = [
   {
      "officeLocation": "Bangalore",
      "address": "#123, Marenahalli signal, near central mall, JP Nagar, Bangalore",
      "email": "ionicfirebaseapp@gmail.com",
      "phoneNumber": 9878675434,
      "storeName": "Online Grocery Store"
   }
]
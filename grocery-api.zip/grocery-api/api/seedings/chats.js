module.exports = [
    {
        "_id" : "5f25b2b487dea20039c82881",
        "userId" : "5f24242faea52d34bb1308be",
        "message" : "Hi",
        "sentBy" : "USER",
        "userName" : "Fire",
    },
    {
        "_id" : "5f25b2be87dea20039c82882",
        "message" : "Hi",
        "sentBy" : "STORE",
        "userId" : "5f24242faea52d34bb1308be",
        "storeId" : "5f24242faea52d34bb1308bd",
        "userName" : "Fire"
    }
]
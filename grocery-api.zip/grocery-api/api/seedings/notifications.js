module.exports = [
	{
		"_id": "5f633afc3813510039eb4930",
		"isRead": true,
		"notifyType": "ORDER_PLACED",
		"orderId": "5f633afc3813510039eb492d",
		"orderID": 10004,
		"title": "New order placed"
	},
	{
		"_id": "5f635a2f3813510039eb4b41",
		"isRead": false,
		"notifyType": "ORDER_ACCEPTED_BY_DELIVERY_BOY",
		"orderId": "5f633afc3813510039eb492d",
		"orderID": 10004,
		"deliveryBoyId": "5f25b0df87dea20039c8287f",
		"deliveryBoyName": "Delivery Boy",
		"title": "Order Accepted by delivery boy"
	}
]

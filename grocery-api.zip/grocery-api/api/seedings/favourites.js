module.exports = [
	{
		"_id": "5f25b2a887dea20039c82880",
		"productId": [
			"5f250502dcb97d00397ac12a",
			"5f250a4ddcb97d00397ac155"
		],
		"userId": "5f24242faea52d34bb1308be"
	}
]
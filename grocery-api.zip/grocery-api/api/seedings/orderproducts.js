module.exports = [
	{
		"_id": "5f60bcdb0e1deac855eb1cd3",
		"productId": "5f250502dcb97d00397ac12a",
		"userId": "5f24242faea52d34bb1308be"
	},
	{
		"_id": "5f633b130e1deac855ee7cbc",
		"productId": "5f6326c857e4f700396960c1",
		"userId": "5f24242faea52d34bb1308be"
	},
	{
		"_id": "5f60bce40e1deac855eb1ced",
		"productId": "5f25063cdcb97d00397ac135",
		"userId": "5f24242faea52d34bb1308be"
	},
	{
		"_id": "5f633b130e1deac855ee7cba",
		"productId": "5f250a4ddcb97d00397ac155",
		"userId": "5f24242faea52d34bb1308be"
	}
]
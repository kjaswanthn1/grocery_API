module.exports = [
	{
		"_id": "5f631b8257e4f700396960a1",
		"amount": 0,
		"isCredited": true,
		"userId": "5f24242faea52d34bb1308be",
		"transactionType": "ORDER_CANCELLED",
		"orderId": "5f631b0357e4f7003969609e",
		"orderID": 10002
	}
]
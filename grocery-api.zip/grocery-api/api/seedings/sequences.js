module.exports = [
	{
		"_id": "5f25b053baa4f15d1cf01107",
		"sequenceType": "ORDER",
		"sequenceNo": 10007
	}
]

module.exports = [
	{
		"_id": "5f2440e89d95c700390caacd",
		"status": true,
		"description": "50% discount ",
		"couponCode": "FLAT50",
		"offerValue": 20,
		"startDate": 1600453800000,
		"expiryDate": 1632508200000,
		"couponType": "PERCENTAGE"
	},
	{
		"_id": "5f2441979d95c700390caace",
		"status": true,
		"description": "FESTIVAL SALE",
		"couponCode": "FESTIVALSALE",
		"offerValue": 30,
		"startDate": 1600281000000,
		"expiryDate": 1600713000000,
		"couponType": "PERCENTAGE"
	},
	{
		"_id": "5f2441e39d95c700390caacf",
		"status": true,
		"description": "Flat 50% off",
		"couponCode": "SALE 50",
		"offerValue": 50,
		"startDate": 1596220200000,
		"expiryDate": 1599849000000,
		"couponType": "PERCENTAGE"
	},
	{
		"_id": "5f63219e57e4f700396960b5",
		"status": true,
		"description": "Get 20% off on purchase of above 100",
		"couponCode": "SPECIAL20",
		"offerValue": 20,
		"startDate": 1600281000000,
		"expiryDate": 1609372800000,
		"couponType": "PERCENTAGE"
	}
]
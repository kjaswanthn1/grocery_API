module.exports = [
	{
		"_id": "5f2433669d95c700390caaa3",
		"status": true,
		"title": "Berries",
		"description": "Rich in vitamin D antifatty acids ",
		"categoryId": "5f242e139d95c700390caaa0",
		"categoryName": "Fruits"
	},
	{
		"_id": "5f24359f9d95c700390caaa7",
		"status": true,
		"title": "Citrus Fruits ",
		"description": "Rich in vitamin C",
		"categoryId": "5f242e139d95c700390caaa0",
		"categoryName": "Fruits"
	},
	{
		"_id": "5f24371c9d95c700390caaab",
		"status": true,
		"title": "Tequila & Mezcal",
		"description": "liquor ",
		"categoryId": "5f242ca99d95c700390caa9f",
		"categoryName": "Liquor"
	},
	{
		"_id": "5f250834dcb97d00397ac146",
		"status": true,
		"title": "Skin Care",
		"description": "Healthy",
		"categoryId": "5f25028edcb97d00397ac114",
		"categoryName": "Cosmetics "
	},
	{
		"_id": "5f25085edcb97d00397ac147",
		"status": true,
		"title": "Root Vegetables ",
		"description": "Root vegetables ",
		"categoryId": "5f242e139d95c700390caaa0",
		"categoryName": "Fruits"
	},
	{
		"_id": "5f250870dcb97d00397ac148",
		"status": true,
		"title": "Veggies ",
		"description": "Greens",
		"categoryId": "5f250210dcb97d00397ac111",
		"categoryName": "Groceries"
	},
	{
		"_id": "5f250886dcb97d00397ac149",
		"status": true,
		"title": "Rice",
		"description": "Groceries",
		"categoryId": "5f250210dcb97d00397ac111",
		"categoryName": "Groceries"
	},
	{
		"_id": "5f25089bdcb97d00397ac14b",
		"status": true,
		"title": "Cakes",
		"description": "Tasty and yummy",
		"categoryId": "5f250773dcb97d00397ac141",
		"categoryName": "Bakery "
	},
	{
		"_id": "5f2508d6dcb97d00397ac14c",
		"status": true,
		"title": "Furnitures",
		"description": "All types of household available",
		"categoryId": "5f250238dcb97d00397ac112",
		"categoryName": "Household"
	},
	{
		"_id": "5f2508eedcb97d00397ac14d",
		"status": true,
		"title": "Milk Products ",
		"description": "Dairy ",
		"categoryId": "5f2502a6dcb97d00397ac115",
		"categoryName": "Dairy"
	},
	{
		"_id": "5f250901dcb97d00397ac14e",
		"status": true,
		"title": "Organic Foods ",
		"description": "Healthy ",
		"categoryId": "5f2502cedcb97d00397ac116",
		"categoryName": "Onions "
	},
	{
		"_id": "5f6324e057e4f700396960ba",
		"status": true,
		"title": "Coffee Powder",
		"description": "Beverage",
		"categoryId": "5f250aa0dcb97d00397ac157",
		"categoryName": "Beverages"
	}
]
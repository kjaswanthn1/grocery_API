module.exports = [
	{
		"_id": "5f243ad69d95c700390caab9",
		"status": true,
		"title": "Fresh and healthy fruits ",
		"description": "Exciting Offers  Flat 50% off on Fruits ",
		"bannerType": "CATEGORY",
		"categoryId": "5f242e139d95c700390caaa0",
		"productId": null,
		"imageId": "5f24427ea0af626666fb6d2f",
		"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596211837587_original_fruits1_hejaDTcvR.jpg",
		"filePath": "/1596211837587_original_fruits1_hejaDTcvR.jpg",
		"categoryName": "Fruits"
	},
	{
		"_id": "5f243b539d95c700390caabb",
		"status": true,
		"title": "Safe and Fresh ",
		"description": "Exciting offers ",
		"bannerType": "CATEGORY",
		"categoryId": "5f250210dcb97d00397ac111",
		"productId": null,
		"imageId": "5f2442b71005831c01bec5a8",
		"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596211894080_original_grocery1_a4hqvQ8d2.jpg",
		"filePath": "/1596211894080_original_grocery1_a4hqvQ8d2.jpg",
		"productName": "Apples",
		"categoryName": "Groceries"
	},
	{
		"_id": "5f243bc29d95c700390caabc",
		"status": true,
		"title": "Skin care",
		"description": "Flat 30 % off on Personal care ",
		"bannerType": "CATEGORY",
		"categoryId": "5f25028edcb97d00397ac114",
		"productId": null,
		"imageId": "5f2443b4a0af626666fb6e2f",
		"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596212148043_original_skin12_1VUI5f999.jpg",
		"filePath": "/1596212148043_original_skin12_1VUI5f999.jpg",
		"categoryName": "Cosmetics "
	}
]
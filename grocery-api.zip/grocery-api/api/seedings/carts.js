module.exports = [
	{
		"_id": "5f633c863813510039eb4a73",
		"productIds": [
			"5f6326c857e4f700396960c1",
			"5f25063cdcb97d00397ac135"
		],
		"couponAmount": 0,
		"walletAmount": 0,
		"isOrderLinked": true,
		"subTotal": 1050,
		"tax": 210,
		"grandTotal": 1260,
		"deliveryCharges": 0,
		"userId": "5f24242faea52d34bb1308be",
		"products": [
			{
				"_id": "5f633c863813510039eb4a74",
				"productId": "5f6326c857e4f700396960c1",
				"productName": "brocolli",
				"unit": "1kg",
				"price": 100,
				"quantity": 1,
				"productTotal": 100,
				"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1600333487459_original_broclli_yDzweGlt_y.jpeg",
				"filePath": "/1600333487459_original_broclli_yDzweGlt_y.jpeg",
				"dealAmount": 0,
				"dealTotalAmount": 0,
				"isDealAvailable": false
			},
			{
				"_id": "5f6356883813510039eb4b36",
				"productId": "5f25063cdcb97d00397ac135",
				"productName": "Whitewalker",
				"unit": "1 Litre",
				"price": 950,
				"quantity": 1,
				"productTotal": 950,
				"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596261897093_original_photo-1520091276903-2d35a24fab56_2x_UyuDewhc9.png",
				"filePath": "/1596261897093_original_photo-1520091276903-2d35a24fab56_2x_UyuDewhc9.png",
				"dealAmount": 0,
				"dealTotalAmount": 0,
				"isDealAvailable": false
			}
		],
		"taxInfo": {
			"taxName": "GST",
			"amount": 20
		},
		"deliveryAddress": "5f2424979d95c700390caa97"
	}
]
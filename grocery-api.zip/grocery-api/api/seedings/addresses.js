module.exports = [
	{
		"_id": "5f2424979d95c700390caa97",
		"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
		"flatNo": "23",
		"mobileNumber": "9876543212",
		"postalCode": "560076",
		"addressType": "HOME",
		"apartmentName": "Milevska",
		"landmark": "Near book store",
		"location": {
			"latitude": 12.872626277861134,
			"longitude": 77.6011914894104
		},
		"userId": "5f24242faea52d34bb1308be",
	}
]
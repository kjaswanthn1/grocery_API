module.exports = [
	{
		"_id": "5f631b0357e4f7003969609e",
		"isOrderAssigned": false,
		"isAcceptedByDeliveryBoy": false,
		"isWalletUsed": false,
		"subTotal": 140,
		"tax": 28,
		"product": {
			"title": "Amul Cheese",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596262133761_original_waldemar-brandt-kPqaqug998Y-unsplash_2x_SMGqBFdXE.png"
		},
		"totalProduct": 1,
		"grandTotal": 168,
		"deliveryCharges": 0,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "CANCELLED",
		"cartId": "5f631ac557e4f7003969609a",
		"orderID": 10002,
		"deliveryDate": "Sat 19-SEP",
		"deliveryTime": "9:00 AM to 12:00 PM",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "e0b95090-f8bd-11ea-a34b-d5610778b197",
		"orderFrom": "WEB_APP",
		"rejectedByDeliveryBoy": []
	},
	{
		"_id": "5f631bec57e4f700396960aa",
		"isOrderAssigned": false,
		"isAcceptedByDeliveryBoy": false,
		"isWalletUsed": false,
		"subTotal": 100,
		"tax": 20,
		"product": {
			"title": "Chocolate Cake",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596262968572_original_cup_cakes_2x_k2J2NdGRX.png"
		},
		"totalProduct": 1,
		"grandTotal": 120,
		"deliveryCharges": 0,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "PENDING",
		"cartId": "5f631ba957e4f700396960a3",
		"orderID": 10003,
		"deliveryDate": "Sat 19-SEP",
		"deliveryTime": "9:00 AM to 12:00 PM",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "6c18a2d0-f8be-11ea-a34b-d5610778b197",
		"orderFrom": "WEB_APP",
		"rejectedByDeliveryBoy": []
	},
	{
		"_id": "5f633afc3813510039eb492d",
		"isOrderAssigned": true,
		"isAcceptedByDeliveryBoy": true,
		"isWalletUsed": false,
		"subTotal": 300,
		"tax": 60,
		"product": {
			"title": "Chocolate Cake",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596262968572_original_cup_cakes_2x_k2J2NdGRX.png"
		},
		"totalProduct": 2,
		"grandTotal": 360,
		"deliveryCharges": 0,
		"couponCode": null,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "DELIVERED",
		"cartId": "5f63278557e4f700396960c3",
		"orderID": 10004,
		"deliveryDate": "Thu 17-SEP",
		"deliveryTime": "03:00 PM to 06:00 PM",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "ef6151c0-f8d0-11ea-9b9f-6d5c05edf916",
		"orderFrom": "USER_APP",
		"rejectedByDeliveryBoy": [],
		"assignedToId": "5f25b0df87dea20039c8287f",
		"assignedToName": "Delivery Boy"
	},
	{
		"_id": "5f633c733813510039eb4a4d",
		"isOrderAssigned": false,
		"isAcceptedByDeliveryBoy": false,
		"isWalletUsed": false,
		"subTotal": 100,
		"tax": 20,
		"product": {
			"title": "Chocolate Cake",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596262968572_original_cup_cakes_2x_k2J2NdGRX.png"
		},
		"totalProduct": 1,
		"grandTotal": 152,
		"deliveryCharges": 32,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "PENDING",
		"cartId": "5f633c5d3813510039eb4a26",
		"orderID": 10005,
		"deliveryDate": "Thu 17-SEP",
		"deliveryTime": "03:00 PM to 06:00 PM",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "cf4880b0-f8d1-11ea-9b9f-6d5c05edf916",
		"orderFrom": "USER_APP",
		"rejectedByDeliveryBoy": []
	},
	{
		"_id": "5f6356dc3813510039eb4b39",
		"isOrderAssigned": false,
		"isAcceptedByDeliveryBoy": false,
		"isWalletUsed": false,
		"subTotal": 1050,
		"tax": 210,
		"product": {
			"title": "Broccoli",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1600333487459_original_broclli_yDzweGlt_y.jpeg"
		},
		"totalProduct": 2,
		"grandTotal": 1260,
		"deliveryCharges": 0,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "PENDING",
		"cartId": "5f633c863813510039eb4a73",
		"orderID": 10006,
		"deliveryDate": "Thu 17-SEP",
		"deliveryTime": "03:00 PM to 06:00 PM",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "8d30d820-f8e1-11ea-9b9f-6d5c05edf916",
		"orderFrom": "WEB_APP",
		"rejectedByDeliveryBoy": []
	},
	{
		"_id": "5f6369184bfd601cb40f01e3",
		"isOrderAssigned": false,
		"isAcceptedByDeliveryBoy": false,
		"isWalletUsed": false,
		"subTotal": 135,
		"tax": 6.4,
		"product": {
			"title": "Tomatoes",
			"imageUrl": "https://ik.imagekit.io/kplhvthqbi/tr:dpr-auto,tr:w-auto/1596261628052_original_lars-blankers-6Z7Ss9jlEL0-unsplash_2x_cCILN_Z77.png"
		},
		"totalProduct": 1,
		"grandTotal": 173.4,
		"deliveryCharges": 32,
		"couponAmount": 0,
		"transactionDetails": {
			"transactionStatus": null,
			"receiptUrl": null,
			"transactionId": null,
			"currency": null
		},
		"address": {
			"address": "262, Muthurayya Swamy Layout, Hulimavu, Bengaluru, Karnataka 560076, India",
			"flatNo": "23",
			"postalCode": "560076",
			"addressType": "HOME",
			"apartmentName": "Milevska",
			"landmark": "Near book store",
			"location": {
				"latitude": 12.872626277861134,
				"longitude": 77.6011914894104
			}
		},
		"user": {
			"firstName": "Fire",
			"lastName": "bases",
			"mobileNumber": "0710394088",
			"email": "user@ionicfirebaseapp.com"
		},
		"userId": "5f24242faea52d34bb1308be",
		"paymentType": "COD",
		"orderStatus": "PENDING",
		"cartId": "5f6368874bfd601cb40f01df",
		"orderID": 10007,
		"deliveryDate": "Sun 20-SEP",
		"deliveryTime": "06:00 PM to 09:00 PM",
		"deliveryMethod": "NORMAL",
		"usedWalletAmount": 0,
		"amountRefunded": 0,
		"currencySymbol": "$",
		"currencyCode": "USD",
		"invoiceToken": "6b5d7a40-f8ec-11ea-89fa-5b77be26c9d7",
		"rejectedByDeliveryBoy": []
	}
]
